/*
 * lcd.c
 *
 * Created: 5/24/2026 6:14:13 PM
 *  Author: iamma
 */ 
#include "lcd.h"
#include "twi.h"
#include <util/delay.h>

static uint8_t backlight = LCD_BL;

static void pcf8574_write(uint8_t data) {
	twi_start(LCD_ADDR << 1 | 0);
	twi_write(data | backlight);
	twi_stop();
}

static void lcd_pulse_enable(uint8_t data) {
	pcf8574_write(data | LCD_EN);
	_delay_us(1);
	pcf8574_write(data & ~LCD_EN);
	_delay_us(50);
}

static void lcd_write_nibble(uint8_t nibble, uint8_t rs) {
	uint8_t data = (nibble << 4) | rs;
	pcf8574_write(data);
	lcd_pulse_enable(data);
}

static void lcd_write_byte(uint8_t byte, uint8_t rs) {
	lcd_write_nibble(byte >> 4, rs);
	lcd_write_nibble(byte & 0x0F, rs);
	_delay_us(100);
}

static void lcd_command(uint8_t cmd) {
	lcd_write_byte(cmd, 0);
}

void lcd_print_char(char c) {
	lcd_write_byte(c, LCD_RS);
}

void lcd_init(void) {
	_delay_ms(50);

	// Secuencia de inicializacion en modo 4 bits
	lcd_write_nibble(0x03, 0);
	_delay_ms(5);
	lcd_write_nibble(0x03, 0);
	_delay_us(150);
	lcd_write_nibble(0x03, 0);
	_delay_us(150);
	lcd_write_nibble(0x02, 0); // Cambiar a 4 bits

	// Configuracion
	lcd_command(0x28); // 4 bits, 2 lineas, 5x8
	lcd_command(0x0C); // Display on, cursor off
	lcd_command(0x06); // Incrementar cursor
	lcd_command(0x01); // Limpiar pantalla
	_delay_ms(2);
}

void lcd_clear(void) {
	lcd_command(0x01);
	_delay_ms(2);
}

void lcd_set_cursor(uint8_t col, uint8_t row) {
	uint8_t row_offsets[] = {0x00, 0x40, 0x14, 0x54};
	lcd_command(0x80 | (col + row_offsets[row]));
}

void lcd_print(const char *str) {
	while (*str)
	lcd_print_char(*str++);
}

void lcd_create_char(uint8_t location, uint8_t *charmap) {
	lcd_command(0x40 | ((location & 0x07) << 3));
	for (uint8_t i = 0; i < 8; i++)
	lcd_print_char(charmap[i]);
}