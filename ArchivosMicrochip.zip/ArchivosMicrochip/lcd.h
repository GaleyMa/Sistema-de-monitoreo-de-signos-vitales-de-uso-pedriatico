/*
 * lcd.h
 *
 * Created: 5/24/2026 6:13:56 PM
 *  Author: iamma
 */ 
#ifndef LCD_H
#define LCD_H

#include <avr/io.h>

#define LCD_ADDR    0x27
#define LCD_COLS    20
#define LCD_ROWS    4

// Bits del PCF8574
#define LCD_RS      (1 << 0)
#define LCD_RW      (1 << 1)
#define LCD_EN      (1 << 2)
#define LCD_BL      (1 << 3)  // Backlight

void lcd_init(void);
void lcd_clear(void);
void lcd_set_cursor(uint8_t col, uint8_t row);
void lcd_print(const char *str);
void lcd_print_char(char c);
void lcd_create_char(uint8_t location, uint8_t *charmap);

#endif