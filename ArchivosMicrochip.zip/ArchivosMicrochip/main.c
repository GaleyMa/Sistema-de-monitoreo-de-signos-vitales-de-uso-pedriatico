#define F_CPU 16000000UL

#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <string.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include "twi.h"
#include "usart.h"
#include "mlx90614.h"
#include "max30102.h"
#include "lcd.h"
#include "timer1.h"

// Promedio temperatura
#define TEMP_SAMPLES 10
float temp_buffer[TEMP_SAMPLES];
uint8_t temp_index = 0;
uint8_t temp_filled = 0;

// Compensacion temperatura corporal (piel -> corporal)
#define TEMP_OFFSET 3.2f

// Mediana de HR
#define HR_HISTORY 7
uint8_t hr_history[HR_HISTORY];
uint8_t hr_hist_index = 0;
uint8_t hr_hist_count = 0;

// Rangos normales
#define HR_MIN      60
#define HR_MAX      130
#define SPO2_MIN    95
#define TEMP_MIN    36.0f
#define TEMP_MAX    37.5f

volatile uint8_t just_woke_up = 0;

// Buffer HR
#define BUFFER_SIZE 50
uint32_t ir_buffer[BUFFER_SIZE];
uint8_t  buf_index = 0;
uint8_t  buf_full  = 0;

// Variables globales de medicion
uint8_t  hr   = 0;
uint8_t  spo2 = 0;
uint32_t red  = 0;
uint32_t ir   = 0;
float    temp = 0.0f;

// Contador de inactividad
volatile uint16_t inactivity_counter = 0;
#define INACTIVITY_LIMIT 600

ISR(INT0_vect) {
}

void setup_wakeup_interrupt(void) {
	EICRA |= (1 << ISC01);
	EICRA &= ~(1 << ISC00);
	EIMSK |= (1 << INT0);
}

void system_sleep(void) {
	lcd_clear();
	lcd_set_cursor(0, 1);
	lcd_print("   Durmiendo... ");
	_delay_ms(1000);
	lcd_clear();

	twi_reset();
	_delay_ms(10);
	twi_start(LCD_ADDR << 1 | 0);
	twi_write(0x00);
	twi_stop();

	max30102_write_reg(REG_MODE_CONFIG, 0x80);

	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	sleep_enable();
	setup_wakeup_interrupt();

	sleep_cpu();

	sleep_disable();
	sei();
	just_woke_up = 1;
}

float smooth_temp(float new_temp) {
	temp_buffer[temp_index++] = new_temp;
	if (temp_index >= TEMP_SAMPLES) {
		temp_index = 0;
		temp_filled = 1;
	}
	uint8_t count = temp_filled ? TEMP_SAMPLES : temp_index;
	float sum = 0;
	for (uint8_t i = 0; i < count; i++)
	sum += temp_buffer[i];
	return sum / count;
}

// SpO2 recalibrado: ratio=1.0 ? 96%, ratio=1.1 ? 94.6%
uint8_t calculate_spo2(uint32_t red, uint32_t ir) {
	if (ir == 0) return 0;
	float ratio = (float)red / (float)ir;
	int16_t spo2 = (int16_t)(110.0f - 14.0f * ratio);
	if (spo2 < 0)   spo2 = 0;
	if (spo2 > 100) spo2 = 100;
	return (uint8_t)spo2;
}

// Mediana de los ultimos N calculos de HR
uint8_t median_hr(uint8_t new_hr) {
	hr_history[hr_hist_index++] = new_hr;
	if (hr_hist_index >= HR_HISTORY) hr_hist_index = 0;
	if (hr_hist_count < HR_HISTORY) hr_hist_count++;

	uint8_t sorted[HR_HISTORY];
	for (uint8_t i = 0; i < hr_hist_count; i++)
	sorted[i] = hr_history[i];

	for (uint8_t i = 0; i < hr_hist_count - 1; i++) {
		for (uint8_t j = 0; j < hr_hist_count - i - 1; j++) {
			if (sorted[j] > sorted[j+1]) {
				uint8_t tmp = sorted[j];
				sorted[j] = sorted[j+1];
				sorted[j+1] = tmp;
			}
		}
	}

	return sorted[hr_hist_count / 2];
}

// HR usando intervalo entre picos
uint8_t calculate_hr(uint32_t *ir_buf, uint8_t size, uint8_t *hr_out) {
	uint32_t max_val = ir_buf[0];
	uint32_t min_val = ir_buf[0];

	for (uint8_t i = 1; i < size; i++) {
		if (ir_buf[i] > max_val) max_val = ir_buf[i];
		if (ir_buf[i] < min_val) min_val = ir_buf[i];
	}

	uint32_t amplitude = max_val - min_val;
	if (amplitude < 500) {
		*hr_out = 0;
		return 0;
	}

	uint32_t threshold = min_val + (amplitude * 6 / 10);

	uint8_t peak_positions[15];
	uint8_t num_peaks = 0;
	uint8_t was_below = (ir_buf[0] < threshold) ? 1 : 0;
	uint8_t last_peak = 0;

	for (uint8_t i = 1; i < size; i++) {
		if (was_below && ir_buf[i] >= threshold &&
		(i - last_peak) >= 3) {
			if (num_peaks < 15) peak_positions[num_peaks++] = i;
			was_below = 0;
			last_peak = i;
			} else if (ir_buf[i] < threshold) {
			was_below = 1;
		}
	}

	if (num_peaks < 2) {
		*hr_out = 0;
		return 0;
	}

	uint16_t total_interval = 0;
	for (uint8_t i = 1; i < num_peaks; i++) {
		total_interval += peak_positions[i] - peak_positions[i-1];
	}
	float avg_interval = (float)total_interval / (num_peaks - 1);

	*hr_out = (uint8_t)(600.0f / avg_interval);

	return (*hr_out >= 40 && *hr_out <= 180);
}

void update_lcd(uint8_t hr, uint8_t spo2, float temp) {
	char buf[8];

	lcd_set_cursor(0, 0);
	lcd_print("HR:        ");
	if (hr > 0) {
		itoa(hr, buf, 10);
		lcd_print(buf);
		lcd_print(" bpm");
		} else {
		lcd_print("-- bpm");
	}

	lcd_set_cursor(0, 1);
	lcd_print("SpO2:         ");
	if (spo2 > 0) {
		itoa(spo2, buf, 10);
		lcd_print(buf);
		lcd_print(" %  ");
		} else {
		lcd_print("-- %  ");
	}

	lcd_set_cursor(0, 2);
	lcd_print("Temp:   ");
	dtostrf(temp, 5, 1, buf);
	lcd_print(buf);
	lcd_print(" C  ");

	lcd_set_cursor(0, 3);
	lcd_print("                    ");
}

int main(void) {
	usart_init();
	twi_init();
	timer1_init();
	lcd_init();

	uint8_t id = max30102_read_reg(REG_PART_ID);
	if (id != 0x15) {
		lcd_set_cursor(0, 0);
		lcd_print("ERROR: MAX30102");
		usart_send_string("ERROR: MAX30102 no encontrado\r\n");
		while(1);
	}

	max30102_write_reg(REG_FIFO_CONFIG, 0x10);
	max30102_init();

	lcd_clear();
	lcd_set_cursor(0, 0);
	lcd_print("  Sistema Listo ");
	lcd_set_cursor(0, 1);
	lcd_print("  Pon el dedo  ");
	lcd_set_cursor(0, 2);
	lcd_print("  en el sensor  ");
	_delay_ms(2000);
	lcd_clear();

	while (1) {
		loop_start:

		if (just_woke_up) {
			just_woke_up = 0;
			twi_reset();
			_delay_ms(100);
			timer1_init();
			max30102_write_reg(REG_FIFO_CONFIG, 0x10);
			max30102_init();
			lcd_init();
			inactivity_counter = 0;
			buf_index = 0;
			buf_full  = 0;
			hr   = 0;
			spo2 = 0;
			temp_index = 0;
			temp_filled = 0;
			hr_hist_index = 0;
			hr_hist_count = 0;
			usart_send_string("Sistema despertado\r\n");
		}

		if (inactivity_counter >= INACTIVITY_LIMIT) {
			system_sleep();
			goto loop_start;
		}

		if (sample_flag) {
			sample_flag = 0;
			inactivity_counter++;

			if (ir > 5000) {
				inactivity_counter = 0;
			}

			temp = smooth_temp(mlx90614_read_temp_object() + TEMP_OFFSET);

			if (max30102_read_fifo(&red, &ir)) {
				if (ir < 5000) {
					hr   = 0;
					spo2 = 0;
					buf_index = 0;
					buf_full  = 0;
					hr_hist_index = 0;
					hr_hist_count = 0;
					max30102_reset_fifo();
					} else if (red < 200000 && ir < 200000) {
					ir_buffer[buf_index++] = ir;
					if (buf_index >= BUFFER_SIZE) {
						buf_index = 0;
						buf_full  = 1;
					}

					spo2 = calculate_spo2(red, ir);

					if (buf_full) {
						uint8_t hr_calc;
						if (calculate_hr(ir_buffer, BUFFER_SIZE, &hr_calc)) {
							hr = median_hr(hr_calc);
						}
					}
					} else {
					max30102_reset_fifo();
				}
			}

			update_lcd(hr, spo2, temp);

			usart_send_string("HR:");
			char buf[8];
			itoa(hr, buf, 10);
			usart_send_string(buf);
			usart_send_string(" SpO2:");
			itoa(spo2, buf, 10);
			usart_send_string(buf);
			usart_send_string(" Temp:");
			dtostrf(temp, 5, 1, buf);
			usart_send_string(buf);
			usart_send_string("\r\n");
		}
	}
}