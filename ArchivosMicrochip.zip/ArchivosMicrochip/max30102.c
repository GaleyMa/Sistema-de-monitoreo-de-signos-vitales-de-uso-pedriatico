/*
 * max30102.c
 *
 * Created: 5/24/2026 3:10:36 PM
 *  Author: iamma
 */ 
#include "max30102.h"
#include "twi.h"
#include <util/delay.h>

void max30102_write_reg(uint8_t reg, uint8_t val) {
	twi_start(MAX30102_ADDR << 1 | 0);
	twi_write(reg);
	twi_write(val);
	twi_stop();
}

uint8_t max30102_read_reg(uint8_t reg) {
	twi_start(MAX30102_ADDR << 1 | 0);
	twi_write(reg);
	twi_start(MAX30102_ADDR << 1 | 1);
	uint8_t val = twi_read_nack();
	twi_stop();
	return val;
}

void max30102_init(void) {
	// Reset
	max30102_write_reg(REG_MODE_CONFIG, 0x40);
	_delay_ms(100);

	// FIFO config: promedio de 4 muestras, FIFO rollover habilitado
	max30102_write_reg(REG_FIFO_CONFIG, 0x10);

	// Modo SpO2 (rojo + IR)
	max30102_write_reg(REG_MODE_CONFIG, 0x03);

	// SpO2 config: ADC 4096nA, 400Hz, 411us pulso
	max30102_write_reg(REG_SPO2_CONFIG, 0x27);

	// Corriente LEDs
	max30102_write_reg(REG_LED1_PA, 0x0C); // LED rojo
	max30102_write_reg(REG_LED2_PA, 0x0C); // LED IR

	// Limpiar punteros FIFO
	max30102_write_reg(REG_FIFO_WR_PTR, 0x00);
	max30102_write_reg(REG_OVF_COUNTER, 0x00);
	max30102_write_reg(REG_FIFO_RD_PTR, 0x00);
}

uint8_t max30102_read_fifo(uint32_t *red, uint32_t *ir) {
	uint8_t wr_ptr = max30102_read_reg(REG_FIFO_WR_PTR);
	uint8_t rd_ptr = max30102_read_reg(REG_FIFO_RD_PTR);

	if (wr_ptr == rd_ptr)
	return 0;

	// Vaciar FIFO completamente, quedarnos con la ultima muestra
	uint32_t last_ir = 0, last_red = 0;
	uint8_t  samples = 0;

	while (wr_ptr != rd_ptr) {
		twi_start(MAX30102_ADDR << 1 | 0);
		twi_write(REG_FIFO_DATA);
		twi_start(MAX30102_ADDR << 1 | 1);

		uint8_t b0 = twi_read_ack();
		uint8_t b1 = twi_read_ack();
		uint8_t b2 = twi_read_ack();
		uint8_t b3 = twi_read_ack();
		uint8_t b4 = twi_read_ack();
		uint8_t b5 = twi_read_nack();
		twi_stop();

		last_ir  = ((uint32_t)(b0 & 0x03) << 16) |
		((uint32_t)b1 << 8) | b2;
		last_red = ((uint32_t)(b3 & 0x03) << 16) |
		((uint32_t)b4 << 8) | b5;

		rd_ptr = (rd_ptr + 1) & 0x1F;
		max30102_write_reg(REG_FIFO_RD_PTR, rd_ptr);
		samples++;

		// Leer wr_ptr actualizado
		wr_ptr = max30102_read_reg(REG_FIFO_WR_PTR);
	}

	if (samples == 0) return 0;

	*ir  = last_ir;
	*red = last_red;
	return 1;
}

void max30102_reset_fifo(void) {
	max30102_write_reg(REG_FIFO_WR_PTR, 0x00);
	max30102_write_reg(REG_OVF_COUNTER, 0x00);
	max30102_write_reg(REG_FIFO_RD_PTR, 0x00);
}
