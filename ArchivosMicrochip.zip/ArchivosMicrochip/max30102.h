/*
 * max30102.h
 *
 * Created: 5/24/2026 3:09:57 PM
 *  Author: iamma
 */ 
#ifndef MAX30102_H
#define MAX30102_H

#include <avr/io.h>

#define MAX30102_ADDR       0x57

// Registros
#define REG_INT_STATUS1     0x00
#define REG_INT_STATUS2     0x01
#define REG_INT_ENABLE1     0x02
#define REG_INT_ENABLE2     0x03
#define REG_FIFO_WR_PTR     0x04
#define REG_OVF_COUNTER     0x05
#define REG_FIFO_RD_PTR     0x06
#define REG_FIFO_DATA       0x07
#define REG_FIFO_CONFIG     0x08
#define REG_MODE_CONFIG     0x09
#define REG_SPO2_CONFIG     0x0A
#define REG_LED1_PA         0x0C
#define REG_LED2_PA         0x0D
#define REG_PART_ID         0xFF

// Funciones
void    max30102_init(void);
uint8_t max30102_read_reg(uint8_t reg);
void    max30102_write_reg(uint8_t reg, uint8_t val);
uint8_t max30102_read_fifo(uint32_t *red, uint32_t *ir);
void max30102_reset_fifo(void);
#endif