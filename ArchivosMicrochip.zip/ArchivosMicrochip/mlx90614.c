/*
 * mlx90614.c
 *
 * Created: 5/24/2026 2:20:49 PM
 *  Author: iamma
 */ 
#include "mlx90614.h"
#include "twi.h"

static float mlx90614_read(uint8_t reg) {
	uint8_t lsb, msb;

	twi_start(MLX90614_ADDR << 1 | 0);
	twi_write(reg);
	twi_start(MLX90614_ADDR << 1 | 1);
	lsb = twi_read_ack();
	msb = twi_read_ack();
	twi_read_nack();
	twi_stop();

	uint16_t raw = ((uint16_t)msb << 8) | lsb;
	return (raw * 0.02f) - 273.15f;
}

float mlx90614_read_temp_object(void) {
	return mlx90614_read(0x07);
}

float mlx90614_read_temp_ambient(void) {
	return mlx90614_read(0x06);
}
