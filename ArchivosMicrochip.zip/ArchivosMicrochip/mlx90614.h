/*
 * mlx90614.h
 *
 * Created: 5/24/2026 2:20:31 PM
 *  Author: iamma
 */ 
#ifndef MLX90614_H
#define MLX90614_H

#include <avr/io.h>

#define MLX90614_ADDR  0x5A

float mlx90614_read_temp_object(void);
float mlx90614_read_temp_ambient(void);

#endif