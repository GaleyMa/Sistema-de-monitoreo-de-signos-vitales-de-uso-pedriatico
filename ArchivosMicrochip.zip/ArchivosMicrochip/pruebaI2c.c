/*
 * pruebaI2c.c
 *
 * Created: 5/24/2026 6:11:13 PM
 *  Author: iamma
 */ 
/*#define F_CPU 16000000UL

#include <util/delay.h>
#include <avr/io.h>
#include "usart.h"

#define TWI_TIMEOUT 10000

static uint8_t twi_wait_timeout(void) {
	uint16_t timeout = TWI_TIMEOUT;
	while (!(TWCR & (1 << TWINT))) {
		if (--timeout == 0)
		return 1; // timeout
	}
	return 0; // ok
}

int main(void) {
	usart_init();

	// Init TWI manual
	TWSR = 0x00;
	TWBR = 72;
	TWCR = (1 << TWEN);

	usart_send_string("Escaneando bus I2C...\r\n");

	for (uint8_t addr = 1; addr < 127; addr++) {
		// START
		TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
		if (twi_wait_timeout()) {
			usart_send_string("Timeout en START\r\n");
			break;
		}

		// Enviar direccion
		TWDR = addr << 1;
		TWCR = (1 << TWINT) | (1 << TWEN);
		if (twi_wait_timeout()) {
			usart_send_string("Timeout en addr\r\n");
			TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
			continue;
		}

		if ((TWSR & 0xF8) == 0x18) {
			usart_send_string("Dispositivo en 0x");
			char buf[5];
			buf[0] = "0123456789ABCDEF"[addr >> 4];
			buf[1] = "0123456789ABCDEF"[addr & 0x0F];
			buf[2] = '\r';
			buf[3] = '\n';
			buf[4] = '\0';
			usart_send_string(buf);
		}

		// STOP
		TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
		_delay_ms(5);
	}

	usart_send_string("Escaneo completo\r\n");
	while(1);
}*/