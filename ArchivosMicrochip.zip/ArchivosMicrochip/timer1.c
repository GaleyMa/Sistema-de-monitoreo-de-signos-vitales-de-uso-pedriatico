#include "timer1.h"

volatile uint8_t sample_flag = 0;


void timer1_init(void) {
	TCCR1A = 0;
	TCCR1B = 0;      // Detener timer primero
	TCNT1  = 0;      // Reset contador
	OCR1A  = 6249;
	TCCR1B = (1 << WGM12) | (1 << CS12);
	TIMSK1 = (1 << OCIE1A);
	sei();
}

ISR(TIMER1_COMPA_vect) {
	sample_flag = 1;
}