/*
 * timer1.h
 *
 * Created: 5/24/2026 6:53:53 PM
 *  Author: iamma
 */ 
#ifndef TIMER1_H
#define TIMER1_H

#include <avr/io.h>
#include <avr/interrupt.h>

extern volatile uint8_t sample_flag;

void timer1_init(void);

#endif