/*
 * twi.c
 *
 * Created: 5/24/2026 2:18:28 PM
 *  Author: iamma
 */ 
#include "twi.h"
#include <util/delay.h>

void twi_init(void) {
	TWSR = 0x00;
	TWBR = TWBR_VAL;
	TWCR = (1 << TWEN);
}

static uint8_t twi_wait(void) {
	uint16_t timeout = 10000;
	while (!(TWCR & (1 << TWINT)))
	if (--timeout == 0) { twi_stop(); return 1; }
	return 0;
}

uint8_t twi_start(uint8_t address) {
	uint16_t timeout;

	// Enviar START
	TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
	timeout = 10000;
	while (!(TWCR & (1 << TWINT)))
	if (--timeout == 0) { twi_stop(); return 1; }

	uint8_t status = TWSR & 0xF8;
	if (status != TWI_START && status != TWI_REP_START)
	return 1;

	// Enviar direccion
	TWDR = address;
	TWCR = (1 << TWINT) | (1 << TWEN);
	timeout = 10000;
	while (!(TWCR & (1 << TWINT)))
	if (--timeout == 0) { twi_stop(); return 1; }

	status = TWSR & 0xF8;
	if (status != TWI_MT_SLA_ACK && status != TWI_MR_SLA_ACK)
	return 1;

	return 0;
}

void twi_stop(void) {
	TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
}
uint8_t twi_write(uint8_t data) {
	TWDR = data;
	TWCR = (1 << TWINT) | (1 << TWEN);
	if (twi_wait()) return 1;
	if ((TWSR & 0xF8) != TWI_MT_DATA_ACK)
	return 1;
	return 0;
}

uint8_t twi_read_ack(void) {
	TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWEA);
	twi_wait();
	return TWDR;
}

uint8_t twi_read_nack(void) {
	TWCR = (1 << TWINT) | (1 << TWEN);
	twi_wait();
	return TWDR;
}
void twi_reset(void) {
	// Reset completo del bus
	TWCR = 0;
	_delay_ms(10);
	TWSR = 0x00;
	TWBR = TWBR_VAL;
	TWCR = (1 << TWEN);
	_delay_ms(10);
}