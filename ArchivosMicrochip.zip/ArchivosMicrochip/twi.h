/*
 * twi.h
 *
 * Created: 5/24/2026 2:18:51 PM
 *  Author: iamma
 */ 
#ifndef TWI_H
#define TWI_H

#include <avr/io.h>

#define F_SCL     100000UL
#define F_CPU_HZ  16000000UL
#define TWBR_VAL  ((F_CPU_HZ / F_SCL - 16) / 2)

#define TWI_START        0x08
#define TWI_REP_START    0x10
#define TWI_MT_SLA_ACK   0x18
#define TWI_MT_DATA_ACK  0x28
#define TWI_MR_SLA_ACK   0x40
#define TWI_MR_DATA_ACK  0x50
#define TWI_MR_DATA_NACK 0x58

void    twi_init(void);
uint8_t twi_start(uint8_t address);
void    twi_stop(void);
uint8_t twi_write(uint8_t data);
uint8_t twi_read_ack(void);
uint8_t twi_read_nack(void);
void twi_reset(void);

#endif