/*
 * usart.c
 *
 * Created: 5/24/2026 2:20:10 PM
 *  Author: iamma
 */ 
#include "usart.h"
#include <stdlib.h>

void usart_init(void) {
	UBRR0H = (UBRR_VAL >> 8);
	UBRR0L =  UBRR_VAL;
	UCSR0B = (1 << TXEN0) | (1 << RXEN0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void usart_send_char(char c) {
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = c;
}

void usart_send_string(const char *str) {
	while (*str)
	usart_send_char(*str++);
}

void usart_send_float(float val, uint8_t decimals) {
	char buf[16];
	dtostrf(val, 6, decimals, buf);
	usart_send_string(buf);
}