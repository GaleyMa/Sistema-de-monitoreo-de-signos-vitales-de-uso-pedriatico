/*
 * usart.h
 *
 * Created: 5/24/2026 2:19:28 PM
 *  Author: iamma
 */ 
#ifndef USART_H
#define USART_H

#include <avr/io.h>

#define BAUD     9600
#define UBRR_VAL (F_CPU / 16 / BAUD - 1)

void usart_init(void);
void usart_send_char(char c);
void usart_send_string(const char *str);
void usart_send_float(float val, uint8_t decimals);

#endif